 <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">

            <div class="info-1">
              <p style="color:#fff;"><?php echo $_SESSION['name'];?></p>
              <!--<a href="#"><i class="fa fa-circle text-success"></i> Online</a> -->
            </div>
          </div>
          
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="active treeview">
              <a href="dashboard.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              
            </li>
			<li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Players</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_player.php"><i class="fa fa-circle-o"></i> Manage Player</a></li>
                <li><a href="add_player.php"><i class="fa fa-circle-o"></i> Add Player</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Teams</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_team.php"><i class="fa fa-circle-o"></i> Manage Teams</a></li>
                <li><a href="add_team.php"><i class="fa fa-circle-o"></i> Add Teams</a></li>
              </ul>
            </li>
          
            <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Organizer</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_organizer.php"><i class="fa fa-circle-o"></i> Manage Organizer</a></li>
                <li><a href="add_organizer.php"><i class="fa fa-circle-o"></i> Add Organizer</a></li>
              </ul>
            </li>
			
			
			 <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Owner</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_owner.php"><i class="fa fa-circle-o"></i> Manage Owner</a></li>
                <li><a href="add_owner.php"><i class="fa fa-circle-o"></i> Add Owner</a></li>
              </ul>
            </li>
            
			<li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Tournament</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_tournament.php"><i class="fa fa-circle-o"></i> Manage tournament</a></li>
                <li><a href="add_tournament.php"><i class="fa fa-circle-o"></i> Add tournament</a></li>
              </ul>
            </li>
			<li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Tournament Details</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_tournament_details.php"><i class="fa fa-circle-o"></i> Manage Tournament Details</a></li>
                <li><a href="add_tournament_details.php"><i class="fa fa-circle-o"></i> Add Tournament Details</a></li>
              </ul>
            </li>
			
			<li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Fixture Details</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_fixture_detail.php"><i class="fa fa-circle-o"></i> Manage Fixture Details</a></li>
                <li><a href="add_fixture_detail.php"><i class="fa fa-circle-o"></i> Add Fixture Details</a></li>
              </ul>
            </li>
           
		   <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Group</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_group.php"><i class="fa fa-circle-o"></i> Manage Group</a></li>
                <li><a href="add_group.php"><i class="fa fa-circle-o"></i> Add Group</a></li>
              </ul>
            </li>
			
			<li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Set Details</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_set_detail.php"><i class="fa fa-circle-o"></i> Manage Set Details</a></li>
                <li><a href="add_set_detail.php"><i class="fa fa-circle-o"></i> Add Set Details</a></li>
              </ul>
            </li>
           
		   <li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Manage Match Details</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="manage_match_detail.php"><i class="fa fa-circle-o"></i> Manage Match Details</a></li>
                <li><a href="add_match_detail.php"><i class="fa fa-circle-o"></i> Add Match Details</a></li>
              </ul>
            </li>
		   
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

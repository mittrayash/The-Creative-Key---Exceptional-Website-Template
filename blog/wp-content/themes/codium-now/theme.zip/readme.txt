Codium Now is a WordPress theme with a thumbnail display on the home page and a fixed menu on top. The theme is fully responsive so it fits well on mobile. The theme also includes the option of Custom Header which is also responsive. The background is very easily changeable so if you do not like white you can choose your color or an image for you. The theme is designed to be effective for SEO. You can add widget on footer and sidebar. For best results do not forget to rebuild your thumbnails with a plugin like "rebuild thumbnails"

Font cm-font is a bundle of the incredible fontawesome : Font Awesome by Dave Gandy - http://fontawesome.io

Features :
-WordPress 4+
-Widget ready
-Translation ready (french include)
-Wp-Pagenavi ready
-Custom color
-Custom background
-Responsive custom header image
-Full responsive design
-Nice google font for the title and description
-Font Awesome for the cool icons menu
-GPL

For the thumbnails you can use this plugin https://wordpress.org/plugins/regenerate-thumbnails/

More information here : http://codiumnow.emploinow.fr

All images and photos display on the theme screenshoot are provided by http://allthefreestock.com/ and are free for use in personal and commercial project. The licence is Creative Commons Zero license.